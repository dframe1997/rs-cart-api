export const JWT_CONFIG = {
  secret: 'secret',
  expiresIn: '12h'
}

export const PG_CONNECTION = 'PG_CONNECTION';
